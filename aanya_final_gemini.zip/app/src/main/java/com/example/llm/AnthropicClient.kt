package com.example.llm

import com.example.persona.AanyaPersonality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class TaskActionJson(
    val action: String, // "click", "type", "scroll_forward", "scroll_backward", "back", "home", "open_app", "finish"
    val target: String = "",
    val text: String = "",
    val explanation: String = ""
)

/**
 * LLM client. The class keeps its old name so the rest of the app is unchanged,
 * but it now talks to the FREE Google Gemini API (key from https://aistudio.google.com/apikey).
 */
class AnthropicClient {

    companion object {
        // Tried in this order. If a model is unavailable (404) or its free quota is used up (429),
        // the next one is tried automatically. The first one that works is remembered.
        private val MODELS = listOf(
            "gemini-2.5-flash",
            "gemini-3.1-flash-lite",
            "gemini-2.5-flash-lite",
            "gemini-3.5-flash"
        )
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

        @Volatile
        private var workingModel: String? = null
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /** Calls Gemini generateContent and returns the reply text. Runs on the caller's (IO) thread. */
    private fun generate(
        apiKey: String,
        systemPrompt: String,
        contents: JSONArray,
        maxTokens: Int
    ): String {
        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
            put("contents", contents)
            put(
                "generationConfig",
                JSONObject().put("maxOutputTokens", maxTokens).put("temperature", 0.8)
            )
        }.toString()

        val order = (listOfNotNull(workingModel) + MODELS).distinct()
        var lastError = "Unknown error"

        for (model in order) {
            val request = Request.Builder()
                .url("$BASE_URL$model:generateContent")
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("content-type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val parts = JSONObject(body)
                        .optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    val sb = StringBuilder()
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            if (!part.optBoolean("thought", false)) sb.append(part.optString("text", ""))
                        }
                    }
                    val text = sb.toString().trim()
                    if (text.isNotEmpty()) {
                        workingModel = model
                        return text
                    }
                    lastError = "Empty response from $model"
                } else {
                    lastError = "Gemini HTTP ${response.code} ($model): ${body.take(300)}"
                    val keyProblem = response.code == 401 || response.code == 403 ||
                        (response.code == 400 && body.contains("API key", ignoreCase = true))
                    if (keyProblem) throw IllegalStateException("Gemini API key galat hai ya allowed nahi hai. $lastError")
                    // 404 (model not available), 429 (quota) and 5xx -> try next model
                }
            }
        }
        throw Exception(lastError)
    }

    suspend fun sendChatMessage(
        apiKey: String,
        conversationHistory: List<Pair<String, String>>, // role, content
        userMessage: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Gemini API Key is not set"))
        }
        try {
            val contents = JSONArray()
            for ((role, content) in conversationHistory.takeLast(6)) {
                contents.put(
                    JSONObject()
                        .put("role", if (role.lowercase() == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", content)))
                )
            }
            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
            )
            Result.success(generate(apiKey, AanyaPersonality.SYSTEM_PROMPT, contents, 1500))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun planNextPhoneAction(
        apiKey: String,
        goal: String,
        currentStep: Int,
        screenElementsSummary: String
    ): Result<TaskActionJson> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Gemini API key required for LLM planner"))
        }
        try {
            val systemPrompt = """
You are an autonomous Android UI agent.
Goal: $goal
Step Number: $currentStep of 12.

Screen UI Elements currently visible:
$screenElementsSummary

Decide the ONE next action to accomplish the goal. Return ONLY raw JSON in this schema:
{
  "action": "click" | "type" | "scroll_forward" | "scroll_backward" | "back" | "home" | "open_app" | "finish",
  "target": "text/description of element or app to target",
  "text": "text to type if action is type, else empty",
  "explanation": "brief reason in Roman Hinglish"
}
SAFETY: Never touch PIN, passwords, OTPs, or financial apps.
""".trimIndent()

            val contents = JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put(
                        "parts",
                        JSONArray().put(
                            JSONObject().put("text", "What is the single next action to execute? Return valid JSON only.")
                        )
                    )
            )

            val rawText = generate(apiKey, systemPrompt, contents, 800)

            val jsonStart = rawText.indexOf('{')
            val jsonEnd = rawText.lastIndexOf('}')
            if (jsonStart != -1 && jsonEnd != -1) {
                val obj = JSONObject(rawText.substring(jsonStart, jsonEnd + 1))
                return@withContext Result.success(
                    TaskActionJson(
                        action = obj.optString("action", "finish"),
                        target = obj.optString("target", ""),
                        text = obj.optString("text", ""),
                        explanation = obj.optString("explanation", "")
                    )
                )
            }
            Result.failure(Exception("Could not parse JSON action from LLM response: $rawText"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
